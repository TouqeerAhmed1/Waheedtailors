<?php

	// Loader - class and connection
	include('loader.php');

	$calendar->delete($_POST['id']);

?>